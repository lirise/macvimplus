# tagbar

使用[majutsushi/tagbar][1]的v2.3版本，v2.3以后的版本在vim打开大文件时，光标移动卡顿。

[1]: https://github.com/majutsushi/tagbar
