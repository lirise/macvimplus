vimplus-startify: A start page plugin for vimplus
===============================================


![][1]

  [1]: https://raw.githubusercontent.com/chxuan/vimplus/master/screenshots/main.png
