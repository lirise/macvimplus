#!/bin/bash
# Author: lirise(alfangj@126.com)
# Create Time: 2021-02-07 19:05:22
# Modified Time: 2021-02-21 15:23:20 

#构建随机数生成函数
function RandomNumber(){   
    min=$1   
    max=$(($2-$min+1))   
    num=$(($RANDOM+1000000000)) #增加一个10位的数再求余   
    echo $(($num%$max+$min))   
}

#设置路径
UserPath=~
File=""$UserPath"/.vim/colorstheme/AirLineThemeList"

# -f 参数判断 $file 是否存在
if [ ! -f "$File" ]; then
  ls "$UserPath"/.vim/plugged/vim-airline-themes/autoload/airline/themes >> "$File"
fi

#获取Airline Theme总数
CountNumber=$(cat "$UserPath"/.vim/colorstheme/AirLineThemeList | grep -c ^.)
#随机生成要获取第几个Theme
Number=$(RandomNumber 1 $CountNumber) 
#获取Teme名称
Colortheme=$(cat "$UserPath"/.vim/colorstheme/AirLineThemeList | sed -n ''"$Number"'p' | cut -f1 -d ".")
#输出到剪贴板
echo "$Colortheme" | pbcopy

exit 0
