#!/bin/bash
# Author: lirise(alfangj@126.com)
# Create Time: 2021-02-07 19:06:29
# Modified Time: 2021-02-21 15:21:51 

#设置文件路径(路径中的用户目录不能用"~"代替不然报错)
UserPath=~
File=""$UserPath"/.vim/colorstheme/ColorsChemeList"

# -f 参数判断 $file 是否存在
if [ ! -f "$File" ]; then
  ls "$UserPath"/.vim/plugged/vim-colorschemes/colors >> "$File"
fi

#从剪切板中获取当前Theme名称
Uname=$(echo "$(pbpaste -Prefer txt)")

#查找并删除当前Theme
sed -i '' '/'"$Uname"'.vim/d' "$File"

exit 0
