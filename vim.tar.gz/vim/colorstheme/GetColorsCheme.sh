#!/bin/bash
# Author: lirise(alfangj@126.com)
# Create Time: 2021-02-07 19:04:07
# Modified Time: 2021-02-21 15:24:45 

#构建随机数生成函数
function RandomNumber(){   
    min=$1   
    max=$(($2-$min+1))   
    num=$(($RANDOM+1000000000)) #增加一个10位的数再求余   
    echo $(($num%$max+$min))   
}

#设置路径
UserPath=~
File=""$UserPath"/.vim/colorstheme/ColorsChemeList"

# -f 参数判断 $file 是否存在
if [ ! -f "$File" ]; then
  ls "$UserPath"/.vim/plugged/vim-colorschemes/colors >> "$File"
fi

#获取Airline Theme总数
CountNumber=$(cat "$UserPath"/.vim/colorstheme/ColorsChemeList | grep -c ^.)
#随机生成要获取第几个Theme
Number=$(RandomNumber 1 $CountNumber) 
#获取Teme名称
ColorsCheme=$(cat "$UserPath"/.vim/colorstheme/ColorsChemeList | sed -n ''"$Number"'p' | cut -f1 -d ".")
#输出到剪贴板
echo "$ColorsCheme" | pbcopy

exit 0
